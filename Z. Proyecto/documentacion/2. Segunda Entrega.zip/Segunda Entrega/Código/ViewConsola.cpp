/*
    Proyecto: Juego de bus
    Curso: Fundamentos de Programación Orientada a Objetos (FPOO)
    Universidad del Valle
    Archivo: View.cpp
    Resumen: Implementación de la clase ViewConsola, clase hija del View, imprime los datos en la consola.

    Descripción:
    Este proyecto pretende llevar a cabo la realización de un videojuego de ordenamiento lógico bidimensional bajo el modelo MVC. 
    El principal objetivo es lograr que cada peatón logre abordar un vehículo de su mismo color y así hasta despejar el paradero.

    
    Autores:
    Estudiante Jhoan Esteban Penagos Lizcano
    Código: 202517537  
    Email: Jhoan.penagos@correounivalle.edu.co

    Estudiante Maria Camila Zuleta Peña
    Código: 
    Email: mariacamilazuletapena@gmail.com
  
    Estudiante: Javier Felipe Contreras Díaz
    Código: 202535936
    Email: contreras.javier@correounivalle.edu.co
		
    Fecha: Junio 2026
*/

#include "Vehiculo.h"
#include <string>
#include "Tablero.h"
#include "ViewConsola.h"
#include "View.h"
#include <iostream>
#include <vector>
#include <thread>
#include <chrono>

ViewConsola::ViewConsola(){
}

void ViewConsola::mostrarMenu(){
  system("clear");
  std::cout<<R"(
                                                         .----------------.  .----------------.  .-----------------. .----------------. 
                                                        | .--------------. || .--------------. || .--------------. || .--------------. |
                                                        | | ____    ____ | || |  _________   | || | ____  _____  | || | _____  _____ | |
                                                        | ||_   \  /   _|| || | |_   ___  |  | || ||_   \|_   _| | || ||_   _||_   _|| |
                                                        | |  |   \/   |  | || |   | |_  \_|  | || |  |   \ | |   | || |  | |    | |  | |
                                                        | |  | |\  /| |  | || |   |  _|  _   | || |  | |\ \| |   | || |  | |    | |  | |
                                                        | | _| |_\/_| |_ | || |  _| |___/ |  | || | _| |_\   |_  | || |   \ `--' /   | |
                                                        | ||_____||_____|| || | |_________|  | || ||_____|\____| | || |    `.__.'    | |
                                                        | |              | || |              | || |              | || |              | |
                                                        | '--------------' || '--------------' || '--------------' || '--------------' |
                                                         '----------------'  '----------------'  '----------------'  '----------------' )"<<std::endl<<std::endl<<std::endl;
}



void ViewConsola::mostrarNivel(int nivel){
  system("clear");
  switch(nivel){
    case 1:{
      std::cout<<R"(
                                                                    █   █ ███ █   █ █████ █          █     
                                                                    ██  █░ █░░█░  █░█░░░░░█░        ██░    
                                                                    █░█ █░░█░░█░░ █░████░░█░░        █░░   
                                                                    █░░██░░█░░ █░█ ░█░░░░ █░░        █░░   
                                                                    █░░ █░███░  █ ░ █████░█████     ███░   
                                                                     ░░  ░░░░░   ░ ░ ░░░░░ ░░░░░     ░░░   
                                                                      ░   ░ ░░░   ░   ░░░░░ ░░░░░     ░░░  )";}
    break;
    case 2:{
      std::cout<<R"(
                                                                    █   █ ███ █   █ █████ █         ███    
                                                                    ██  █░ █░░█░  █░█░░░░░█░       █ ░░█   
                                                                    █░█ █░░█░░█░░ █░████░░█░░       ░ █░░  
                                                                    █░░██░░█░░ █░█ ░█░░░░ █░░        █ ░ ░ 
                                                                    █░░ █░███░  █ ░ █████░█████    █████░  
                                                                     ░░  ░░░░░   ░ ░ ░░░░░ ░░░░░    ░░░░░  
                                                                      ░   ░ ░░░   ░   ░░░░░ ░░░░░    ░░░░░ )";}
    break;
    case 3:{
      std::cout<<R"(
                                                                    █   █ ███ █   █ █████ █        ████    
                                                                    ██  █░ █░░█░  █░█░░░░░█░        ░░░█   
                                                                    █░█ █░░█░░█░░ █░████░░█░░       ███░░  
                                                                    █░░██░░█░░ █░█ ░█░░░░ █░░        ░░█ ░ 
                                                                    █░░ █░███░  █ ░ █████░█████    ████░░  
                                                                     ░░  ░░░░░   ░ ░ ░░░░░ ░░░░░    ░░░░ ░ 
                                                                      ░   ░ ░░░   ░   ░░░░░ ░░░░░    ░░░░  )";}
    break;
  }
  std::cout<<std::endl;
}


//Muestra el mapa, completo con cada modificación que se haya hecho.
void ViewConsola::mostrarMapa(Tablero& datosMapa){
  int filas = datosMapa.getFilas();
  int columnas = datosMapa.getColumnas();
  std::vector<Pasajero*>& filaPasajeros = datosMapa.getFilaPasajeros();
  std::vector<Vehiculo*>& zonaRecogida = datosMapa.getZonaRecogida();
  std::vector<std::vector<Vehiculo*>>& zonaCoches = datosMapa.getZonaCoches();
  
  //puntuacion
  std::cout<<"Número de peatones por recoger: "<<filaPasajeros.size()<<std::endl<<std::endl;
  
  //Acá se usan punteros, para imprimir la fila de pasajeros.
  Pasajero* auxPasajero;
  int tamanoFila = filaPasajeros.size()-1;
  std::cout<<"             ";
  //Se imprimen primero todos a partir del 4 pasajero en cierto orden, para que parezcan muñequitos.
  for(int i = 3; i <=tamanoFila; i++){
    std::cout<<"@    ";
  }
    std::cout<<std::endl<<"           ";
    for(int i = 3; i <=tamanoFila; i++){
    auxPasajero = filaPasajeros[i];
    char color = auxPasajero->getColor();
    std::cout<<"/("<<color<<")\\";
    }
    std::cout<<std::endl<<"            ";
    for(int i = 3; i <=tamanoFila; i++){
      std::cout<<"IL   ";
    }
    //Luego se imrimen los otros 3, para que se vea como una fila.
  std::cout<<std::endl;
  for(int i = 2; i >= 0; i--){
    auxPasajero = filaPasajeros[i];
    char color = auxPasajero->getColor();
    std::cout<<"            ";
    std::cout<<"@"<<std::endl;
    std::cout<<"          ";    
    std::cout<<"/("<<color<<")\\"<<std::endl;
    std::cout<<"           ";  
    std::cout<<"IL"<<std::endl;
  }
  
  //Ahora se imprime la zona de recogida donde los pasajeros abordan buses. Acá se imprime según el tamaño del coche.
  Vehiculo* auxRecogida;
  for(int j = 0; j <= 2; j++){
    std::cout<<"           ";
    for (int i = 0; i < 4; i++){
      auxRecogida = zonaRecogida[i];
      //Si el coche no es real, imprime el espacio vacío
      if(auxRecogida == nullptr){
        std::cout<<"[  ]";
      }
      //en caso de que el vehículo sea real y no un espacío vacío, imprime el coche.
      else{
          int tamCoche = auxRecogida->getTamano();
          if(j < tamCoche){
          char orientacion = auxRecogida->getOrientacion();
          char color = auxRecogida->getColor();
          std::string coche;
          coche = orientacion;
          coche += color;
          std::cout<<"["<<coche<<"]";
          }
          else {
           std::cout<<"[  ]";
          }
          }
      }
    std::cout<<std::endl;
  }
 
 
 //Ahora imprimo el tablero de buses
  std::cout<<std::endl;
  std::cout<<"                                           ←COLUMNAS→"<<std::endl;
  std::cout<<std::endl;
  std::cout<<"                          ===1===2===3===4===5===6===7===8===9===10==="<<std::endl;  
  std::cout<<"                         ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌"<<std::endl;
  Vehiculo* auxVehiculo;
  std::vector <int> vectorFilas = {1,2,3,4,5,6,7,8,9,10};
  for (int i = 0 ; i < filas; i++){
    if (i > 8) {
      std::cout<<"                        "<<vectorFilas[i]<<"||";
    }
    else if(i <= 8) {
      std::cout<<"                         "<<vectorFilas[i]<<"||";
    }
    for (int j = 0; j < columnas; j++){
      if(zonaCoches[i][j] == nullptr){
        std::cout<<"[  ]";
      }
      else{

        auxVehiculo = zonaCoches[i][j];
        char orientacion = auxVehiculo->getOrientacion();
        char color = auxVehiculo->getColor();
        std::string coche;
        coche = orientacion;
        coche += color;
        std::cout<<"["<<coche<<"]";
      }
    }
      std::vector<std::string> vectorDir ={
        "                      ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌",
        "  ↑                                      1.Arriba                     ",
        "  F                                       ↑↑↑↑↑↑↑                     ",
        "  I                            ←←←←←←←←←              →→→→→→→→        ",
        "  L                          3.Izquierda             4.Derecha        ",
        "  A                                                                   ",
        "  S                                       ↓↓↓↓↓↓                      ",
        "  ↓                                      2.Abajo                      ",
        "                      ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌",
        "",
        ""};
    std::cout<<"||"<<vectorFilas[i]<<vectorDir[i];
    std::cout<<std::endl;
  }
  std::cout<<"                          ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌"<<std::endl; 
  std::cout<<"                          ===1===2===3===4===5===6===7===8===9===10==="<<std::endl;  
  std::cout<<std::endl<<std::endl<<std::endl;
}


void ViewConsola::pantallaDerrota(){
    system("clear");
    std::cout<<R"(
                                                                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡀⠀⠀⠀ ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⣀⡀⠀⠀⠠⢾⡿⠂⠀⠀ ⢠⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣾⣻⣏⣯⡽⡽⢶⣄⠀⠀⠀⠀⠀⠀ ⣼⢻⣀⡀⠀⠀⠐⠆⠀⠀⠀⠀⣀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⣶⣦⠀⠀⢰⡿⠓⠂⣲⡛⡟⢫⡍⢽⡆⠀⠀⠀⢶⣾ ⣿⣨⡿⠿⠛⠀⠀⠀⠀⠀⣴⣿⢯⣹⣿⣍⠛⢦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠻⠿⠛⣤⣤⢹⣯⣩⠍⠤⠰⠆⡒⢛⣛⡟⢰⣄⠀⠀⠀ ⢸⣿⠀⠀⠀⠀⢠⣦⡄⣼⣃⣙⣳⣯⣿⢿⣟⣉⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⡀⠀⠀⠀⠉⠋⠈⢳⣶⢂⣢⡍⣤⠭⢴⣾⠃⠛⠿⠀⠀⠀ ⠀⠿⠇⠀⠀⠀⠈⠉⠀⣿⡉⠉⢹⣇⣀⢀⣈⣩⣼⡇⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢶⣾⣿⣧⣀⠀⠀⠀⠀⣀⣠⠉⠛⠶⠷⠿⠿⠛⠁⠀⠀⠀⠀⠀⠀ ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣿⡦⠤⣬⣉⣩⣭⣤⡟⠀⠀⠀⣦⣿⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⣶⠀⠀⣰⡿⢿⣿⠁⢀⡀⠀⠀⠿⠛⠀⠀⠀⠀⠀⠀⠸⠿⠀⠀⢠⣾⣧⠀ ⠀⠀⠀⢠⣦⡀⠀⢸⣦⡄⠈⠛⠶⢭⣭⣷⡞⠋⠀⠀⠀⢹⣿⣿⡟⠀⣀⣦⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣠⣤⣀⣀⠀⠀⠀⠈⠀⠈⠉⠀⠸⠟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠛⠋⠀ ⠀⠀⠀⠈⠉⠀⠀⠈⠛⠇⠀⠀⠀⠀⠀⢈⣷⣤⠀⠀⠀⠀⠻⠋⠀⠀⠿⠛⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠀⠀⢀⣤⠞⠋⠁⠀⣼⠇⠉⠙⣶⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⣦⡄⠀⠀⠀⠈⠀⠀⣶⡄⠀⠀⣀ ⣠⣤⠤⡤⠤⠤⣤⣄⡀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠀⠀⠀⠀⠠⣶⡆⠀⣠⣴⣾⣿⣿⣷⡶⣤⡀⠀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠀⢠⣿⠁⠀⠀⠀⣸⡧⠀⠀⠀⢻⡜⢷⡀⠀⠀⠀⠸⠗⠀⠀⠀⠀⠉⠛⠃⠀⠀⠀⠀⠀⠀⣈⣵⢶⣿⡭ ⠁⠚⠛⠛⠁⣀⣤⣾⣿⣷⣄⠀⠀⢀YOU LOSE⡶⠀⠀⠈⢠⣾⠋⣹⣿⣿⠿⠋⢀⡾⠻⣆⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠀⡿⠸⣶⠀⢠⡾⠋⠀⠀⠀⠀⠀⢿⣜⣧⠀⢠⣦⠀⢀⡄⠀⠀⠀⠀⠀⠀⢠⡄⠀⢀⣴⣾⠿⠓⣈⣥⠶ ⠰⠶⠄⠶⣼⠋⢹⣿⣿⣿⡝⣇⠀⠘⢿⣿⣯⠀⠀⠀⠀⠀⠀⠀⣾⢩⣍⣉⡁⣀⣤⠾⠋⢀⣤⣿⡆⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⢸⡇⠀⠘⢷⣜⣷⣤⣤⠶⢤⣄⣀⡀⠙⣿⡀⠘⠋⠀⢸⣿⣄⣴⡆⠀⠀⠐⣿⡗⠀⢿⣫⠴⢚⣣⡬⠤⠴ ⠶⠰⢤⠄⢻⡄⠀⠈⠁⣸⢇⣿⠄⠀⠀⠉⠀⠀⠀⠀⣤⠀⠀⠀⣏⠙⠿⠷⠟⠉⣀⣴⢶⣾⠛⣻⡇⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠈⣷⣦⠀⠀⠀⠉⠹⣇⠀⠀⠈⠉⡇⢲⡟⠀⠀⠀YOU LOSE⠀⠀⠀⢀⣴⠟⢵⢞⣫⡥⠶⠒⠒ ⠒⠶⠦⣤⣄⣙⠷⠶⠞⣫⡾⠁⠀YOU LOSE⠸⣿⠂⠀⠀⢻⡟⠓⠚⠛⡛⠉⠙⢋⣿⡾⣿⠃⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠀⠘⢿⣧⡀⠀⠀⠀⠈⢳⡀⠀⠀⣷⡟⠁⠀⠀⠀⠀⢸⣿⠟⢿⣦⠀⠀⠀⠀⠈⣅⠀⠀⠈⠁⠀⠀⠀⠀ ⠀⣰⡆⠀⠀⠉⠉⠛⠉⠁⠀⣀⡀⠀⣴⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠻⣷⡶⠿⢿⣷⣛⣿⣥⡾⠋⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⣄⠀⠀⠀⠙⠿⣷⣦⡀⠀⢈⣷⣤⠾⠋⠀⠀⢀⣀⣀⠀⠸⠟⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⠂⠀⠀⠀⢠⣦⡀ ⠘⡿⠃⠀⠀⠀⣤⣤⠀⠀⠘⠿⢃⣀⣿⣧⣤⡀⠀⠀⠀⣠⡀⠀⠀⠀⣌⠙⠓⠶⠿⠿⠛⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠉⢠⣿⡆⠀⠀⠀⠉⠉⡉⠉⠉⢀⣦⠀⠀⠀⠸⠿⠟⠀⠀⠀⢰⣷⠄⠀⠀⠀⠀⠀⠉⠛⢀⣀⣠⣤⡟⠘⣧ ⣄⡀⠀⠀⠀⠀⠙⠋⠀⠀⠀⠀⠈⠛⢻⣿⠋⠁⠀⠀⠀⠛⠃⠀⠀⠀⠻⣿⠆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠀⠈⢀⣤⣀⣄⡀⠺⠿⠀⠀⠘⣿⠁⠀⠀⠀⣀⣤⡦⠀⠀⠀⠁⠀⠀⠀⣴⢤⣄⣤⠶⣿⣭⠿⠛⠛⠛⠓ ⠿⣿⣶⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⠛⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡀⠀⠀⠀⠀⠀⠀⠀⣤⡀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠀⣰⣿⣿⣿⣿⣷⠂⠀⠀⠀⠀⠀⠀⠀⢰⠟⢡⡟⠀⠀⠀⠀⢠⡄⠀⠀⢙⣷⣌⣻⣾⣿⣿⣶⣷⠀⠀⠀ ⢠⡿⠉⠻⣿⠶⢛⣿⠇⠀⠀⠀⣄⠀⠀⠀⠀⢴⣿⠆⠀⡀⠀⠀⠀⠻⠿⠀⠀⠀⣀⣤⠀⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⢠⣼⣿⣿⣿⣿⡍⠀⠀⠀⢴⣶⠀⠀⠀⣿⠀⢸⡆⠀⠀⠀⠀⣿⡷⠀⢠⣼⠟⣿⣯⣿⣿⣿⡿⠉⠀⠀⣠ ⡾⠃⠀⠀⠘⣷⢾⡅⠀⠀⠀⠀⢿⣿⠀⠀⠀⠀⣀⠀⢰⣷⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⠃⢀⣴⡀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠘⠻⢿⣿⣿⠿⠁⠀⠀⠀⠈⠁⠀⠀⠀⢻⣄⠀⠻⢦⣀⣀⡀⠈⠁⠀⣘⣧⣸⡿⠷⢿⡿⠋⠀⠀⣠⡾⠋ ⠀⠀⠀⠀⣠⡿⣿⣧⠀⠀⠀YOU LOSE ⠻⣿⡿⢾⣶⣶⠆⠀⣠⡄⠀⠀⠈⠁⠀⠺⠿⠃⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⣤⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣤⣶⣤⠀⠀⠀⠀⠙⠳⠶⠴⠿⠋⠁⠀⠀⢸⣏⠁⣿⣧⣀⡀⣤⡤⠞⠛⠉⠀⠀ ⠀⠀⢀⣴⠏⠀⣿⢩⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣟⣿⣾⡏⠁⠀⠘⠻⡿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠘⠿⠏⠀⠀⠀⠀⠰⡿⠆⠀⠀⠘⠿⠛⠀⠀⠀⠀⠀⠀⢀⣀⠀⠀⠀⠀⠀⠀⠛⣿⣻⡄    YOU DEAD ⣀⣴⠟⠁⠀⠀⣿⣿⠃⠀⠀⠀⢰⣷⣦⡀⠀⠀⠻⠋⠀⠘⠃⠀⠀⠀⠀⢀⣴⣾⣛⣉⣉⣹⣷⣦⣄⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠀⠀⣀⣤⣤⠴⢶⣤⣄⡀⠀⠀⠀⠀⠀⠛⠀⠀⠘⠿⠀⠀⣷⣄⠀⠀⠀⢼⡟⣷⣀⣀⣀⣀⣀⣀⣤⠶⠚ ⠉⠀⠀⠀⣠⣿⣿⡇⠀⣶⡆⠀⠘⠻⠟⠁⠀⢀⣤⣿⠂⠀⠀⠀⠀⠀⣰⢿⣍⡛⠲⠿⠷⠒⢛⣩⡿⣦⣀⠀⠀⠀⠀
                                                                          ⠀⠀⢀⣴⢿⡿⣿⣿⡏⢹⠿⢾⡝⢳⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠛⠟⠀⠀⠀⣾⠃⠈⣿⣍⠉⠉⠉⠀⠀⠀⠀ ⠀⣀⡴⢞⣿⡟⢿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠛⠋⠀⠀⢀⣠⣴⣶⣿⣄⠈⠉⠛⠒⠚⠛⢉⣁⣤⢾⡿⢿⡓⢦⡄
                                                                          ⠀⢀⣾⡷⠾⣿⣿⠻⠶⠶⢤⣀⠷⢿⣿⣦⠀⣤⡀⠀⣶⡀⣀⠀⠀⣀⡀⠀⠀⠀⠉⠛⠻⠧⣍⢳⣦⣤⣤⠶⠶⠛ ⣋⣩⣴⣿⣿⠛⠛⠃⠀⠀⠀⠀⠀⢀⢀⣤⣀⣤⡶⠟⠀⢰⡟⢻⣏⠀⣧⣌⡙⠛YOU LOSE⠞⣻⣧⠾⢃⣼⠇
                                                                          ⠀⣼⢿⢻⡗⠛⠋⢠⡞⠻⣦⡿⣀⡈⠻⣿⡄⠻⢧⣾⣿⢿⡿⠀⠀⠻⠃⠀⠀⢀⣀⡀⠀⠀⠛⠛⠷⢾⣿⣏⠉⢹ ⣿⡷⠞⠋⠁⣾⣦⡀⠀⠀⠀⠀⣴⣿⣿⣿⣿⣿⢾⠃⠀⠈⠳⠦⣭⣓⣿⣿⣿⡿⣿⣿⣿⣿⣶⣾⣿⣿⠷⠚⠉⠀⠀
                                                                          ⠀⣿⠷⣾⠷⢠⣤⣄⠙⣦⠈⣀⢿⡝⠒⢻⠇⠀⠈⠉⣿⡟⠿⠀⠀⠀⠀⠀⠀⠈⠛⠃⠀⠀⠀⠀⠀⠀⠀⠻⣦⠟ ⠀⠀⠀⠀⠀⠛⠛⠀⠀⠀⣼⣾⣃⣤⠉⣽⣿⠿⠛⠁⠀⠀⠀⠀⠀⠀⠉⠙⢿⣿⡿⠽⠿⠿⣻⣿⠟⠁⠀⠀⠀⠀⠀
                                                                          ⠀⠻⣆⣶⢤⡿⠀⠈⠷⠛⣴⢿⡎⠻⣆⡿⠀⠀⠀⠀⠉⠀YOU LOSE⠀⠀⠀⠀⠀⠀⢀⣴⢿⣦⠀⠀⠀⠀ ⢀⣰⣄⠀⠀⠀⠀⠀⢠⣴⣿⣿⣿⣯⠾⠋⠁⠀⠀⠀⠀⢾⡷⠀⠀⢀⠀⠀⠀⠈⠉⠙⠛⠉⠉⠀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠹⣾⡇⠸⣟⠳⣄⣀⡿⢻⡅⣰⡟⢱⣿⡦⠀⠀⠀⠀⠀⣠⡀⠀⠀⣠⡶⠛⠛⢶⣄⠀⠀⠿⠼⠟⠀⠀⠀⠀ ⠈⢻⡏⠀⠀⠀⣶⡆⠀⠈⣿⣿⠿⠿⡆⠀⠀⠀⠀⡀⠀⠀⠀⠀⣦⣾⣧⡄⠀⠀⠀⣤⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠈⠛⠦⣽⣷⣮⣉⣤⠾⠟⠁⠀⠀⠉⠀⠀⠀⠀⠀⠀⠉⣀⠀⢸⣿⡇⠀⠀⠸⣿⠗⢒⡀⠀⠀⠀⢴⡷⠀ ⠀⠀⠀⠀⣀⡴⠎⠁⠀⠀⠛⠁⠀⣀⠀⠀⠀⢰⣾⣷⡀⠀⠀⠀⣼⢿⡿⠁⠀⠀⠻⣿⠗⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠶⠀⠀⠀⠀⠀⢸⣿⠆⠈⠹⢷⣤⣶⣼⠿⣦⡈⠙⠲⠦⢤⣤⣀⣠ ⣤⡤⠶⠛⠉⠀⠀⠀⠀⠀⠀⠀⢾⣿⠄⠀⠀⠈⠿⠉⠀⠀⠀⠀⠀⢀⡁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠀⠀⠀⠀⢾⡧⠀⠀⠀⠀⢠⣷⠀⠀⠀⠀⠀⣰⣷⡄⠈⠉⠀⠀⠀⠀⠈⢻⣇⠀⠈⠙⠶⣤⣀⡀⠀⠀⢀ ⣀⣤⠀⠀⠀⢰⣷⠄⠘⠛⠀⢀⣈⣉⣀⡀⠀⠀⠀⠀⠀⢠⣾⣦⠀⠹⠟⠀⣾⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣼⣿⣤⣤⠀⠀⠀⠈⠛⠁⠀⠀⠀⠀⠛⠀⠀⠀⠀⠀⠙⢦⣄⡀⠈⠉⠉⠉⠉ ⠁⣀⣤⠾⠂⠀⠀⠀⣠⠶⠛⢉⡽⣻⢋⡽⢛⣶⣄⡀⠀⠀⠙⠉⠀⠀⢰⣶⣿⣷⣾⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠙⣿⡏⠁⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⡀⠀⠀⠀⠈⠉⠙⠓⠒⠒⠛ ⠋⠉⠀⢠⡄⠀⣠⣾⡵⠶⣞⣿⠷⣋⡾⣱⡞⠋⣾⠻⣄⠀⠀⢀⠀⠀⠀⢹⣿⢿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠁⠀⠀⢸⣿⠇⢀YOU LOSE⣤⡀⠉⠁⠀⢰⣶⢶⣄⣤⡄⠀⠀⠀ ⠀⠀⠀⠀⠀⢠⡿⠶⠒⢚⣋⣠⣾⣿⠞⢋⣤⡾⠋⣰⢿⡆⠀⠸⣷⡆⠀⠙⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠀⠀⣰⣿⣿⣷⣏⠁⣼⡿⣿⣿⣆⠀⠀⠈⢛⣿⣏⢻⣷⣄⠀⠀ ⠀⢾⡇⠀⠀⣿⠓⠒⢛⣯⠿⠷⠛⢁⣤⠾⠁⣀⣼⢋⣼⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠿⠿⢠⣿⢺⣿⣿⠛⠐⢿⣿⣿⢏⣿⡀⠀⠀⠘⠳⠿⠈⠛⠉⠀⠺ ⣿⠆⠀⢀⡀⣿⡋ ⢉YOU LOSE⣤⡾⠋⠀⣿⢡⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⣿⣿⡝⠋⣠⣤⣤⣄⠀⢼⣿⡇⠀⠀YOU LOSE⠀⣴ ⠀⠀⠀⠈⠁⠘⣿⣟⣋⣩⣭⣩⡤⠾⠋⣰⠶⠶⠞⢃⣾⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢿⣷⠀⢿⣯⣭⡿⣃⡾⠋⠀⠀⠀⠻⠗⢠⣤⠀⢶⣶⣿ ⣧⣶⠀⠀⠀⠀⠘⢿⣭⣥⣴⠶⢤⡾⠛⢉⣠⡶⣞⡿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠛⠒⠛⠛⠛⠉⠀⠀⠀⠀⠀⠀⠀⠘⠛⠀⠀⣽⣿ ⣿⠁⠀⠀⠀⠀⠀⠀⠙⠳⢶⣶⣶⣶⣲⣾⡿⠞⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                                                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠀ ⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀

    )"<<std::endl<<std::endl<<std::endl;
        
}

void ViewConsola::pantallaVictoria(){
        system("clear");
        std::cout<<R"(                                                         
                                                                              Felicidades usted ha ganado este nivel
                                                                              ________¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶ 
                                                                              ________¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶ 
                                                                              ___¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶ 
                                                                              _¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶ 
                                                                              ¶¶¶¶______¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶_______¶¶¶¶ 
                                                                              ¶¶¶_______¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶________¶¶¶ 
                                                                              ¶¶________¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶________¶¶¶ 
                                                                              ¶¶¶_____¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶______¶¶¶ 
                                                                              ¶¶¶____¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶____¶¶¶¶ 
                                                                              _¶¶¶___¶¶¶_¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶_¶¶¶____¶¶¶ 
                                                                              _¶¶¶¶___¶¶¶_¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶_¶¶¶¶__¶¶¶¶ 
                                                                              ___¶¶¶¶__¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶_¶¶¶¶¶ 
                                                                              ____¶¶¶¶¶¶¶¶_¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶_¶¶¶¶¶¶¶¶¶ 
                                                                              ______¶¶¶¶¶¶__¶¶¶¶¶¶¶¶¶¶¶¶¶¶___¶¶¶¶¶¶ 
                                                                              _______________¶¶¶¶¶¶¶¶¶¶¶¶ 
                                                                              _________________¶¶¶¶¶¶¶¶ 
                                                                              ___________________¶¶¶¶ 
                                                                              ___________________¶¶¶¶ 
                                                                              ___________________¶¶¶¶ 
                                                                              ___________________¶¶¶¶ 
                                                                              _______________¶¶¶¶¶¶¶¶¶¶¶¶ 
                                                                              ____________¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶ 
                                                                              ____________¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶ 
                                                                              ____________¶¶¶____________¶¶¶ 
                                                                              ____________¶¶¶___________¶¶¶ 
                                                                              ____________¶¶¶____________¶¶¶ 
                                                                              ____________¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶ 
                                                                              ____________¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶ 
                                                                              __________¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶ 
                                                                              _________¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶

  )"<<std::endl;
  std::this_thread::sleep_for(std::chrono::milliseconds(8000));
}
ViewConsola::~ViewConsola(){
}
