#ifndef PASAJERO_H
#define PASAJERO_H




class Pasajero{

private:

char color;

public:
Pasajero(char auxColor);
char getColor();

};

#endif
