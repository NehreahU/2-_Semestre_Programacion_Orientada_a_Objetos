#ifndef CONTROLLER_H
#define CONTROLLER_H
#include <vector>
#include "Model.h"
#include "View.h"


class Controller{

private:

int nivel;
bool verificador;
View& vista;
Model& model;


public:

Controller(Model& auxModelo, View& auxVista);
bool iniciarJuego();
void mostrarMapa();
void movimientosVehiculos();
void pushPasajerosBus();
void verificarZonaRecogida();
bool verificarDerrota();
};

#endif
