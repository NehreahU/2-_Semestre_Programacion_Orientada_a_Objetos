#ifndef TABLERO_H 
#define TABLERO_H 

#include "Vehiculo.h"
#include "Pasajero.h"
#include <vector>

class Tablero{

private:

int filas;
int columnas;
std::vector<std::vector<Vehiculo*>> zonaCoches; 
std::vector<Pasajero*> filaPasajeros;
std::vector<Vehiculo*> zonaRecogida;
std::vector<Vehiculo*> zonaVictoria;
bool verificarDerrota;

public:

Tablero();
Tablero(int auxFilas, int auxColumnas);
void setZonaCoches(Vehiculo* auxVehiculo);
void pushFilaPasajeros(Pasajero*);
bool verificarColision(int posX,int posY);
bool verificarDireccion(char direccion, int posX, int posY);
bool getVerificarDerrota();
bool moverVehiculo(int posX, int posY, int tam);
void pushPasajerosBus(Pasajero* peaton, int i);
void verificarZonaRecogida();
void pushZonaVictoria(Vehiculo* carro);

std::vector<Pasajero*>& getFilaPasajeros();
std::vector<Vehiculo*>& getZonaRecogida();
std::vector<std::vector<Vehiculo*>>& getZonaCoches();
std::vector<Vehiculo*>& getZonaVictoria();
int getFilas();
int getColumnas();

};

#endif
