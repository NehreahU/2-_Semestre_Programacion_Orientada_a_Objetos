#ifndef VIEW_H
#define VIEW_H

#include <string>
#include "Tablero.h"

class View{

private: 

public:

View();

void mostrarMenu();
void mostrarNivel(int nivel);
void mostrarMapa(Tablero& datosMapa);
};

#endif
