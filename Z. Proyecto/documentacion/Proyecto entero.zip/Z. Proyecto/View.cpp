#include "Vehiculo.h"
#include <string>
#include "Tablero.h"
#include "View.h"
#include <iostream>
#include <vector>

View::View(){
}

void View::mostrarMenu(){
  system("clear");
  std::cout<<R"(
                                                         .----------------.  .----------------.  .-----------------. .----------------. 
                                                        | .--------------. || .--------------. || .--------------. || .--------------. |
                                                        | | ____    ____ | || |  _________   | || | ____  _____  | || | _____  _____ | |
                                                        | ||_   \  /   _|| || | |_   ___  |  | || ||_   \|_   _| | || ||_   _||_   _|| |
                                                        | |  |   \/   |  | || |   | |_  \_|  | || |  |   \ | |   | || |  | |    | |  | |
                                                        | |  | |\  /| |  | || |   |  _|  _   | || |  | |\ \| |   | || |  | '    ' |  | |
                                                        | | _| |_\/_| |_ | || |  _| |___/ |  | || | _| |_\   |_  | || |   \ `--' /   | |
                                                        | ||_____||_____|| || | |_________|  | || ||_____|\____| | || |    `.__.'    | |
                                                        | |              | || |              | || |              | || |              | |
                                                        | '--------------' || '--------------' || '--------------' || '--------------' |
                                                         '----------------'  '----------------'  '----------------'  '----------------' )"<<std::endl<<std::endl<<std::endl;
                                                                        
}



void View::mostrarNivel(int nivel){
  system("clear");
  switch(nivel){
    case 1:{
      std::cout<<R"(
                                                                    █   █ ███ █   █ █████ █          █     
                                                                    ██  █░ █░░█░  █░█░░░░░█░        ██░    
                                                                    █░█ █░░█░░█░░ █░████░░█░░        █░░   
                                                                    █░░██░░█░░ █░█ ░█░░░░ █░░        █░░   
                                                                    █░░ █░███░  █ ░ █████░█████     ███░   
                                                                     ░░  ░░░░░   ░ ░ ░░░░░ ░░░░░     ░░░   
                                                                      ░   ░ ░░░   ░   ░░░░░ ░░░░░     ░░░  )";}
    break;
    case 2:{
      std::cout<<R"(
                                                                    █   █ ███ █   █ █████ █         ███    
                                                                    ██  █░ █░░█░  █░█░░░░░█░       █ ░░█   
                                                                    █░█ █░░█░░█░░ █░████░░█░░       ░ █░░  
                                                                    █░░██░░█░░ █░█ ░█░░░░ █░░        █ ░ ░ 
                                                                    █░░ █░███░  █ ░ █████░█████    █████░  
                                                                     ░░  ░░░░░   ░ ░ ░░░░░ ░░░░░    ░░░░░  
                                                                      ░   ░ ░░░   ░   ░░░░░ ░░░░░    ░░░░░ )";}
    break;
    case 3:{
      std::cout<<R"(
                                                                    █   █ ███ █   █ █████ █        ████    
                                                                    ██  █░ █░░█░  █░█░░░░░█░        ░░░█   
                                                                    █░█ █░░█░░█░░ █░████░░█░░       ███░░  
                                                                    █░░██░░█░░ █░█ ░█░░░░ █░░        ░░█ ░ 
                                                                    █░░ █░███░  █ ░ █████░█████    ████░░  
                                                                     ░░  ░░░░░   ░ ░ ░░░░░ ░░░░░    ░░░░ ░ 
                                                                      ░   ░ ░░░   ░   ░░░░░ ░░░░░    ░░░░  )";}
    break;
  }
  std::cout<<std::endl;
}


void View::mostrarMapa(Tablero& datosMapa){
  int filas = datosMapa.getFilas();
  int columnas = datosMapa.getColumnas();
  std::vector<Pasajero*>& filaPasajeros = datosMapa.getFilaPasajeros();
  std::vector<Vehiculo*>& zonaRecogida = datosMapa.getZonaRecogida();
  std::vector<std::vector<Vehiculo*>>& zonaCoches = datosMapa.getZonaCoches();
  
  Pasajero* auxPasajero;
  int tamanoFila = filaPasajeros.size()-1;
  std::cout<<"             ";
  for(int i = 3; i <=tamanoFila; i++){
    std::cout<<"@    ";
  }
    std::cout<<std::endl<<"           ";
    for(int i = 3; i <=tamanoFila; i++){
    auxPasajero = filaPasajeros[i];
    char color = auxPasajero->getColor();
    std::cout<<"/("<<color<<")\\";
    }
    std::cout<<std::endl<<"            ";
    for(int i = 3; i <=tamanoFila; i++){
      std::cout<<"IL   ";
    }
  std::cout<<std::endl;
  for(int i = 2; i >= 0; i--){
    auxPasajero = filaPasajeros[i];
    char color = auxPasajero->getColor();
    std::cout<<"            ";
    std::cout<<"@"<<std::endl;
    std::cout<<"          ";    
    std::cout<<"/("<<color<<")\\"<<std::endl;
    std::cout<<"           ";  
    std::cout<<"IL"<<std::endl;
  }
  
  Vehiculo* auxRecogida;
  for(int j = 0; j <= 2; j++){
    std::cout<<"           ";
    for (int i = 0; i < 4; i++){
      auxRecogida = zonaRecogida[i];

      if(auxRecogida == nullptr){
        std::cout<<"[  ]";
      }
      else{
          int tamCoche = auxRecogida->getTamano();
          if(j < tamCoche){
          char orientacion = auxRecogida->getOrientacion();
          char color = auxRecogida->getColor();
          std::string coche;
          coche = orientacion;
          coche += color;
          std::cout<<"["<<coche<<"]";
          }
          else {
           std::cout<<"[  ]";
          }
          }
      }
    std::cout<<std::endl;
  }
 
  std::cout<<std::endl;
  std::cout<<"                                           ←COLUMNAS→"<<std::endl;
  std::cout<<std::endl;
  std::cout<<"                          ===1===2===3===4===5===6===7===8===9===10==="<<std::endl;  
  std::cout<<"                         ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌"<<std::endl;
  Vehiculo* auxVehiculo;
  std::vector <int> vectorFilas = {1,2,3,4,5,6,7,8,9,10};
  for (int i = 0 ; i < filas; i++){
    if (i > 8) {
      std::cout<<"                        "<<vectorFilas[i]<<"||";
    }
    else if(i <= 8) {
      std::cout<<"                         "<<vectorFilas[i]<<"||";
    }
    for (int j = 0; j < columnas; j++){
      if(zonaCoches[i][j] == nullptr){
        std::cout<<"[  ]";
      }
      else{

        auxVehiculo = zonaCoches[i][j];
        char orientacion = auxVehiculo->getOrientacion();
        char color = auxVehiculo->getColor();
        std::string coche;
        coche = orientacion;
        coche += color;
        std::cout<<"["<<coche<<"]";
      }
    }
      std::vector<std::string> vectorDir ={
        "                      ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌",
        "  ↑                                      1.Arriba                     ",
        "  F                                       ↑↑↑↑↑↑↑                     ",
        "  I                            ←←←←←←←←←              →→→→→→→→        ",
        "  L                          3.Izquierda             4.Derecha        ",
        "  A                                                                   ",
        "  S                                       ↓↓↓↓↓↓                      ",
        "  ↓                                      2.Abajo                      ",
        "                      ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌",
        "",
        ""};
    std::cout<<"||"<<vectorFilas[i]<<vectorDir[i];
    std::cout<<std::endl;
  }
  std::cout<<"                          ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌"<<std::endl; 
  std::cout<<"                          ===1===2===3===4===5===6===7===8===9===10==="<<std::endl;  
  std::cout<<std::endl<<std::endl<<std::endl;
}



