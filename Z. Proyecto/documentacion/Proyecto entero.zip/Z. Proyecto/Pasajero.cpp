#include "Pasajero.h"


Pasajero::Pasajero(char auxColor): color(auxColor){
}

char Pasajero::getColor(){
  return color;
}
