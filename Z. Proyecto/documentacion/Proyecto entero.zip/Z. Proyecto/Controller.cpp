#include "Controller.h"
#include "Model.h"
#include "View.h"
#include <iostream>
#include "Tablero.h"
#include <thread>
#include <chrono>
#include <string>

Controller::Controller(Model& auxModelo, View& auxVista): vista(auxVista), model(auxModelo){
}



//Inicia el juego e imprime el mapa
bool Controller::iniciarJuego(){
  
  //Muestra un titulo de menú.
 vista.mostrarMenu();
  //elegir el nivel 
 std::cout<<"¿Ingrese el número del nivel desea cursar?: \n1.Nivel uno \n2.Nivel dos \n3.Nivel tres. \n0. Ingrese cero para cerrar."<<std::endl<<std::endl;
 while(!(std::cin>>nivel) || nivel < 0 || nivel >3){
   std::cout<<"¿Ingrese un número válido del nivel desea cursar?: \n1.Nivel uno \n2.Nivel dos \n3.Nivel tres \n0. Ingrese cero para cerrar."<<std::endl<<std::endl;
   std::cin.clear();
   std::cin.ignore();
 }

  if(nivel == 0){
    return false;
  }
 
  //cargar el archivo según el nivel
  model.cargarTxt(nivel);
  model.cargarVehiculosEnTablero();
  model.cargarPasajerosEnTablero();
  
  //mostrar mapa
  vista.mostrarNivel(nivel);
  vista.mostrarMapa(model.getTablero());
  return true;
}
          

void Controller::mostrarMapa(){
 //mostrar mapa
 vista.mostrarNivel(nivel);
 vista.mostrarMapa(model.getTablero());
}

//pide coordenadas, las verifica, pide dirección y sea una entrada válida. Verifica la colisión del vehículo, de no haber entra en un bucle que mientras mover vehículo sea true verifica sus coordenadas más actuales y se mueve.
//también, en caso de que el vehículo esté en los bordes, resta uno al tamaño, así elimina la dirección del último borde y ya.
void Controller::movimientosVehiculos(){
    //Verifica que la posición seleccionada corresponda a un vehículo en el tablero, sino entra en bucle hasta que el usuario ingrese unas coordenadas válidas.
   auto[posX, posY] = model.verificarPosicionVehiculo();
   Vehiculo* carro = model.getTablero().getZonaCoches()[posX][posY];    
   int tam = carro->getTamano();
   //Verifica que la dirección ingresada sea válida y convierte el input int (1,2,3,4) en una dirección tipo char ('^','v','<','>')
   char dir = model.verificarInputDireccion();

   //verifica colisión antes de seguir con el movimiento.
   if (!(model.getTablero().verificarColision(posX, posY))){
    while(model.moverVehiculo(posX,posY,tam,dir)){
      posX = carro->getPosX();
      posY = carro->getPosY();
      //antes de seguir, vemos si el vehículo está en un borde, de ser así se le reduce el tamaño para que el próximo while tam elimine su propia posicion en el tablero de punteros        
      if (carro->getPosX() == 0 ||carro->getPosY() == 0 || carro->getPosX()== model.getTablero().getFilas()-1 ||carro->getPosY()== model.getTablero().getColumnas()-1){
        tam -= 1;
      }
          vista.mostrarNivel(nivel);
          vista.mostrarMapa(model.getTablero());
          std::this_thread::sleep_for(std::chrono::milliseconds(300));    
    }
          vista.mostrarNivel(nivel);
          vista.mostrarMapa(model.getTablero());    
   }
}


//Genera un for de 0 a 3, ya que es el numero de zonas de recogida que hay. 4 zonas donde se aparcan los coches para recoger peatones.
void Controller::pushPasajerosBus(){
  for(int i = 0; i <4; i++){
    vista.mostrarNivel(nivel);
    vista.mostrarMapa(model.getTablero());
    std::this_thread::sleep_for(std::chrono::milliseconds(400));
    model.pushPasajerosBus(i);
    vista.mostrarNivel(nivel);
    vista.mostrarMapa(model.getTablero());
    std::this_thread::sleep_for(std::chrono::milliseconds(400));
  }
}

void Controller::verificarZonaRecogida(){
  model.verificarZonaRecogida();
}


bool Controller::verificarDerrota(){
 return model.getVerificarDerrota();
}

