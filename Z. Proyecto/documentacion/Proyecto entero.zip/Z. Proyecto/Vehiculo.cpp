#include "Vehiculo.h"
#include <vector>
#include <string>


Vehiculo::Vehiculo(char auxTipo,
        char auxColor,
        char auxOrientacion,  
        int auxTamano, 
        int auxPosX, 
        int auxPosY): 
        tipo(auxTipo), 
        color(auxColor),
        orientacion(auxOrientacion),
        tamano(auxTamano),
        posX(auxPosX),
        posY(auxPosY) {
        sillas.clear();
}

char Vehiculo::getColor(){
  return color;
}

char Vehiculo::getTipo(){
  return tipo;
}

int Vehiculo::getTamano(){
  return tamano;
}

char Vehiculo::getOrientacion(){
  return orientacion;
}

int Vehiculo::getPosX(){
  return posX;
}

int Vehiculo::getPosY(){
  return posY;
}

int Vehiculo::getSizeSillas(){
  return sillas.size();
}

void Vehiculo::setPos(int x,int y){
  posX = x;
  posY = y;
}

void Vehiculo::pushPasajerosBus(Pasajero* peaton){
  sillas.push_back(peaton);
}
