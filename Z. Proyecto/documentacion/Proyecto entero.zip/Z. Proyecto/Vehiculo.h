#ifndef VEHICULO_H
#define VEHICULO_H
#include "Vehiculo.h"
#include "Pasajero.h"
#include <vector>

class Vehiculo {

private:

char tipo;
char color;
char orientacion;
int tamano;
int posX;
int posY;
std::vector<Pasajero*> sillas;

public:

//CONSTRUCTOR
Vehiculo(char auxTipo,char auxColor,char auxOrientacion, int auxTamano, int auxPosX, int auxPosY);

char getColor();
char getTipo();
int getTamano();
char getOrientacion();
int getPosX();
int getPosY();
int getSizeSillas();
void setPos(int x,int y);
void pushPasajerosBus(Pasajero* peaton);

};

#endif
