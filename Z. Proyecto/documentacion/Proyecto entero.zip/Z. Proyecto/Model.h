#ifndef MODEL_H
#define MODEL_H

#include "Vehiculo.h"
#include "Pasajero.h"
#include "Tablero.h"


#include <vector>
#include <string>

class Model{

private:
std::vector<Vehiculo> vehiculos;
std::vector<Pasajero> pasajeros;
Tablero tablero;


public:
Model();
void cargarTxt(int nivel);
void cargarVehiculosEnTablero();
void cargarPasajerosEnTablero();
bool verificarColision(int posX, int posY);
bool verificarDireccion(char direccion, int posX, int posY);
char verificarInputDireccion();
std::tuple<int,int> verificarPosicionVehiculo();
void verificarZonaRecogida();
bool moverVehiculo(int posX, int posY, int tam,char direccion);
void pushPasajerosBus(int i);

bool getVerificarDerrota();
Tablero& getTablero();
};

#endif
