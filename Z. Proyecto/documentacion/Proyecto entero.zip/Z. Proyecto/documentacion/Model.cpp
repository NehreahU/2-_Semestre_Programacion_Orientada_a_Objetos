
#include "Vehiculo.h"
#include "Pasajero.h"
#include "Tablero.h"
#include "Model.h"
#include <iostream>

#include <vector>
#include <string>
#include <fstream>
#include <sstream>

Model::Model(){
}

void Model::cargarTxt(int nivel){
  vehiculos.clear();
  pasajeros.clear();
  std::string archivo = "nivel";
  archivo += std::to_string(nivel);
  archivo += ".txt";
  std::ifstream mapa(archivo);
  std::string auxLine;
  
  while(std::getline(mapa, auxLine)){
    char color;
    char tipo;
    char orientacion;
    int tamano;
    int posX;
    int posY;
    int filas;
    int columnas;
    std::string temp;
    std::stringstream linea(auxLine);
    std::getline(linea,temp,',');
    tipo = temp[0];
    if (tipo == 'D'){
      std::getline(linea,temp,',');
      filas = std::stoi(temp);
      std::getline(linea,temp,',');
      columnas = std::stoi(temp);
      Tablero auxTab(filas,columnas);
      tablero = auxTab;
    }
    else if (tipo == 'P'){
      std::getline(linea,temp,',');
      color = temp[0];
      Pasajero pasajero(color);
      pasajeros.push_back(pasajero);
    }
    else if (tipo== 'V'){ 
      std::getline(linea,temp,',');
      color = temp[0];
      std::getline(linea,temp,',');
      orientacion =temp[0];
      std::getline(linea,temp,',');
      tamano=std::stoi(temp); 
      std::getline(linea,temp,',');
      posX=std::stoi(temp);
      std::getline(linea,temp,',');
      posY = std::stoi(temp);
      Vehiculo vehiculo(tipo,color,orientacion,tamano,posX,posY);
      vehiculos.push_back(vehiculo);
    }
  }
  mapa.close();
}


void Model::cargarVehiculosEnTablero(){
  for (auto& v: vehiculos){
    tablero.setZonaCoches(&v);
  }
}

void Model::cargarPasajerosEnTablero(){
  for (auto& p: pasajeros){
    tablero.pushFilaPasajeros(&p);
  }
}
bool Model::verificarColision(int posX, int posY){
  bool colision = tablero.verificarColision(posX, posY);
  return colision;
}

bool Model::verificarDireccion(char direccion,  int posX, int posY){
  bool direccionCorrecta = tablero.verificarDireccion(direccion, posX, posY);
  return direccionCorrecta;
}

char Model::verificarInputDireccion(){
    std::string dir;
    std::cout<<"¿Ingrese el número de la dirección en la que se desea mover: "<<std::endl;  
    //mientras dir que es la dirección sea falso, y además dir no sea 1, 2, 3 o 4, se hace un while
    while(!(std::cin>>dir) || !(dir == "1" || dir == "2" || dir == "3" || dir == "4")){
      std::cout<<"¿Ingrese el número de la dirección en la que se desea mover: "<<std::endl;
     std::cout<<std::endl;
     std::cin.clear();
     std::cin.ignore();
      
      }
      //convierte dir en un char llamado direccion
      char direccion;
      direccion = dir[0];
      switch(direccion){
        case '1': {
          dir = "^";
        }
        break;
        case '2': {
          dir = "v";
        }
        break;
        case '3': {
          dir = "<";
        }
        break;
        case '4': {
          dir = ">";
        }
        break;
      }
      //al finalizar dirección cambia de ser un char numerico a un char de direccion <,^,>,v
      direccion = dir[0];
      return direccion;
}






std::tuple<int,int> Model::verificarPosicionVehiculo(){
  int posX;
  int posY;
  std::cout<<"Qué vehículo desea mover, ingrese las filas [↓↑] de enter e ingrese las columnas [←→] y de enter"<<std::endl;
  std::cin>>posX>>posY;
  //le resta uno a cada pos, ya que c++ lee desde 0.
  posX-=1;
  posY-=1;
  while(!(posX < tablero.getFilas())|| !(posX>=0) || !(posY<tablero.getColumnas())  || !(posY > 0)){
      std::cout<<"Error. Posición no vállida"<<std::endl;
      std::cout<<"Qué vehículo desea mover, ingrese las filas [↓↑] de enter e ingrese las columnas [←→] y de enter"<<std::endl;
      std::cin>>posX>>posY;
      posX-=1;
      posY-=1;  
  }
  Vehiculo* carro = tablero.getZonaCoches()[posX][posY];
  //Mientras el puntero vehículo sea falso hace un bucle para pedir la posición nuevamente y restarle uno a cada uno nuevamente.
  while( !(carro)){
    std::cout<<"Error. Posición no válida"<<std::endl;
    std::cout<<"Qué vehículo desea mover, ingrese las filas [↓↑] de enter e ingrese las columnas [←→] y de enter"<<std::endl;
    std::cin>>posX>>posY;
    posX-=1;
    posY-=1;
  }
  return {posX, posY};
}



bool Model::moverVehiculo(int posX, int posY, int tam,char direccion){
        if(tablero.verificarDireccion(direccion, posX, posY)){
          //Ya que sabemos que la dirección es correcta, invocamos la zona de recogida 
          std::vector<Vehiculo*>& zonaRecogida = tablero.getZonaRecogida();
          if((zonaRecogida[0])  && (zonaRecogida[1]) && (zonaRecogida[2]) && (zonaRecogida[3]) && !(tablero.moverVehiculo(posX,posY,tam))){
            verificador = true;
          }
          //mientras se pueda mover y se mueva el vehículo hará     
          if(tablero.moverVehiculo(posX,posY,tam)){
            return true;
          }
        }
  return false;
}

void Model::pushPasajerosBus(int i){

    //llamo una referencia de zona de recogida
    std::vector<Vehiculo*>& zonaRecogida =  tablero.getZonaRecogida();
    //Busco el vehículo que está en la zona de recogida
    Vehiculo* carro = zonaRecogida[i];
    //unicamente si hay un carro en esa zona de recogida, se ejecuta el código:
    if(carro){
          char colorCarro = carro->getColor();
          std::vector<Pasajero*>& filaPasajeros = tablero.getFilaPasajeros();
          Pasajero* peaton = filaPasajeros[0];
          int capacidad = carro->getTamano()*2;
          int estCap = carro->getSizeSillas();
        if(peaton){
          char colorPeaton = peaton->getColor(); 
          while((estCap < capacidad) && (colorCarro == colorPeaton) ){
              tablero.pushPasajerosBus(peaton, i);
              estCap = carro->getSizeSillas();
              if(!(filaPasajeros.empty())){
                peaton = filaPasajeros[0];
                colorPeaton = peaton->getColor();
                if(colorPeaton != colorCarro){
                  i=0;
                 }     
              }
              else if(filaPasajeros.empty()){
                colorPeaton = 'N';
              }
          }
        }
      }
}


void Model::verificarZonaRecogida(){
  std::vector<Vehiculo*>& zonaRecogida = tablero.getZonaRecogida();
 for (int i = 0; i < 4; i++){
  if (zonaRecogida[i]){
    if (zonaRecogida[i]->getTamano()*2 == zonaRecogida[i]->getSizeSillas()){
        std::cout<<zonaRecogida[i]->getTamano()*2<<"   "<<zonaRecogida[i]->getSizeSillas();
      tablero.pushZonaVictoria(zonaRecogida[i]);
      zonaRecogida.erase(zonaRecogida.begin()+i);
    }
  }
 }
}


Tablero& Model::getTablero(){
  return tablero;
}



void Model::verificarZonaRecogida(){
  std::vector<Vehiculo*>& zonaRecogida = tablero.getZonaRecogida();
 for (auto i = zonaRecogida.begin(); i != zonaRecogida.end();){
  Vehiculo* v = &i; 
  std::cout<<v->getTipo()<<v->getTamano()<<v->getTamano()*2<<"   "<<v->getSizeSillas()<<std::endl;
  if (v){
  std::cout<<"dentro del if "<<v->getTipo()<<v->getTamano()<<v->getTamano()*2<<"   "<<v->getSizeSillas()<<std::endl;
    if (v->getTamano()*2 == v->getSizeSillas()){
      tablero.pushZonaVictoria(v);
      i = zonaRecogida.erase(i);
    }
    else {
      i++;
    }
  }
  else {
      i++;
    }
 }
}
